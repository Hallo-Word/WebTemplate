<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['seo']['default']['title']= 'ACI —— 开源PHP后台管理系统';
$config['seo']['default']['keywords']= '自带后台管理，用户管理、用户组管理、权限管理、菜单管理、模块管理、扩展管理基本功能，适合于所有程序的基本需求,由此可以扩展出各类实用应用...';
$config['seo']['default']['decriptions']= ' 基于PHP Codeigniter 开源框架功能扩展 ';

/* End of file seo.php */
/* Location: ./application/config/seo.php */
