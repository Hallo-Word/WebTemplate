<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.mxhichina.com';
$config['smtp_port'] = 465;
$config['smtp_user'] = '';
$config['smtp_pass'] = '';
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";

$config['owner_address'] = "";