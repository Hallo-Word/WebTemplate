<?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
</body>
</html>
