Dashboard Layouts
=================

Building something from scratch? These vanilla dashboard layouts will get you up and running in no time.

**Note:** we've used [holder.js](https://github.com/imsky/holder) for labeled cell placeholders, which can be safely removed as you make these layouts your own.
